//adpadfs : adpadfs.h
//Written By: Bradley Sadowsky

#ifndef ADPADFS_H_
#define ADPADFS_H_

int curse(int len);
#endif
