/*adpadfs : adpadfs.h
  Written By: Bradley Sadowsky */

#ifndef ADPADFS_H_
#define ADPADFS_H_

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>


int curse(int len);
int mid_finger(void);
int a_wrapper(void);
void chk_egg(int egg);

#endif
