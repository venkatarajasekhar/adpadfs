/*adpadfs : chk_egg.c
  Written By: Bradley Sadowsky */
#include "adpadfs.h"

void chk_egg(int egg) {
  if ( egg == 69 ) {
    mid_finger();
  } else if ( egg == 420 ) {
    mid_finger();
  }
}
